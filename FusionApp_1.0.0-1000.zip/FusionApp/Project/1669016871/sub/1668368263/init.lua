name="聊天宝典"
template="tool"
