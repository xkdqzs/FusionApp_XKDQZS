template="tool"
name="AZ功能助手"
