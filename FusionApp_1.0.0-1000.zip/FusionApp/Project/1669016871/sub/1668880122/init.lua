name="COPY运算机器人"
template="tool"
