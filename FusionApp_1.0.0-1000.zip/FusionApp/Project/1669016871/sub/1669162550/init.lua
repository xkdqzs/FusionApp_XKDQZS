template="tool"
name="播放中心"
