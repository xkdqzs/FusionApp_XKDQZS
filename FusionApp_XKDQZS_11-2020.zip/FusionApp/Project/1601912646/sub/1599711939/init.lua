name="资源影片2"
template="tool"
