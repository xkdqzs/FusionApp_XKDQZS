name="资源影片1"
template="tool"
