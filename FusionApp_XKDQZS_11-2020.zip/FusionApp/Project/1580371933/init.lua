appver="3.2"
appcode="201101"
appname="社交聊天"
template="tool"
packagename="com.xkdqzs.sjlt"
user_permission={
  [1]	= "ACCESS_COARSE_LOCATION" ;
  [2]	= "ACCESS_FINE_LOCATION" ;
  [3]	= "ACCESS_NETWORK_STATE" ;
  [4]	= "ACCESS_WIFI_STATE" ;
  [5]	= "INTERNET" ;
  [6]	= "WRITE_EXTERNAL_STORAGE" ;
  } ;
