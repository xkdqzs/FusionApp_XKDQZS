template="tool"
name="资源采集"
