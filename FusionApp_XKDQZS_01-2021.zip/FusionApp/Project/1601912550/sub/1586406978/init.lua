template="tool"
name="设备桌面壁纸"
