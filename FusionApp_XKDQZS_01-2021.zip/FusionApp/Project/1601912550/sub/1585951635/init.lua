template="tool"
name="设备信息"
