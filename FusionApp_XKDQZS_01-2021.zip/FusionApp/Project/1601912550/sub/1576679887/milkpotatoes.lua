require "import" 
import "android.net.Uri"
import "android.content.Intent"
import "android.widget.*" 
import "android.view.*"

function getData(name,key)
  local data = this.getApplicationContext().getSharedPreferences(name,0).getString(key,nil)--325-5273-2
  return data
end

function putData(name,key,value)
  this.getApplicationContext().getSharedPreferences(name,0).edit().putString(key,value).apply()--3255-2732
  return true
end

function qq_group(group_num)
  local url="mqqapi://card/show_pslcard?src_type=internal&version=1&uin="..tostring(group_num).."&card_type=group&source=qrcode"
  activity.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
end

function qq_person(qq_num)
  local url="mqqwpa://im/chat?chat_type=wpa&uin="..tostring(qq_num)
  activity.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
end

function viatelegram(username)
  local url = "tg://resolve?domain="..tostring(username)
  activity.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
end

function sendmail(mail_add,title,content)
  local i = Intent(Intent.ACTION_SENDTO)
  i.setType("message/rfc822")
  i.setData(Uri.parse("mailto:"..mail_add));
  i.putExtra(Intent.EXTRA_EMAIL,mail_add)
  i.putExtra(Intent.EXTRA_SUBJECT,title)
  i.putExtra(Intent.EXTRA_TEXT,content)
  i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); 
  activity.startActivity(Intent.createChooser(i, "请选择打开方式"))
end

function openInBrowser(url)
  viewIntent = Intent("android.intent.action.VIEW",Uri.parse(url))
  activity.startActivity(viewIntent)
end

function copytext(text)
  activity.getSystemService(Context.CLIPBOARD_SERVICE).setText(text)
end

function decodeURL(s)
  s = string.gsub(s, '%%(%x%x)', function(h) return string.char(tonumber(h, 16)) end)
  return s
end

function encodeURL(s)
  s = string.gsub(s, "([^%w%.%- ])", function(c) return string.format("%%%02X", string.byte(c)) end)
  return string.gsub(s, " ", "+")
end
