appcode="210101"
appver="3.3"
user_permission={
  [1]	= "ACCESS_COARSE_LOCATION" ;
  [2]	= "ACCESS_FINE_LOCATION" ;
  [3]	= "ACCESS_NETWORK_STATE" ;
  [4]	= "ACCESS_WIFI_STATE" ;
  [5]	= "INTERNET" ;
  [6]	= "WRITE_EXTERNAL_STORAGE" ;
  } ;
packagename="com.xkdqzs.qtgj"
appname="其他工具"
template="tool"
