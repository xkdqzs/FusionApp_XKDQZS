appcode="210326"
appname="资源市场"
template="tool"
appver="3.5"
packagename="com.xkdqzs.zysc"
user_permission={
  [1]	= "ACCESS_COARSE_LOCATION" ;
  [2]	= "ACCESS_FINE_LOCATION" ;
  [3]	= "ACCESS_NETWORK_STATE" ;
  [4]	= "ACCESS_WIFI_STATE" ;
  [5]	= "INTERNET" ;
  [6]	= "WRITE_EXTERNAL_STORAGE" ;
  } ;
