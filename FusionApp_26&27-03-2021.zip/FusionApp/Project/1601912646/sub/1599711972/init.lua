template="tool"
name="视频播放器"
