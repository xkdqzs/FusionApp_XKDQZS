name="带壳截图"
template="tool"
