template="tool"
name="应用管理"
