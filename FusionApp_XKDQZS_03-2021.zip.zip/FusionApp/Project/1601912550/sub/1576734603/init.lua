template="tool"
name="10 软件仓库"
