template="tool"
name="B2 直播放器"
