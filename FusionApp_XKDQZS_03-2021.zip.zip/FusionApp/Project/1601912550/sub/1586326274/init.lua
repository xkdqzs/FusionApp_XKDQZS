name="短链接生成"
template="tool"
