template="tool"
name="影视播放器"
