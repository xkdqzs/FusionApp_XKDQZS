name="资源采集"
template="tool"
